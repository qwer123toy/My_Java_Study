# @SpringBootApplication
 - @ComponentScan : 해당 패키지를 기준으로 수행됨
 - @EnableAutoConfiguration : 스프링부트 자동 설정


![칼로바이02](https://github.com/user-attachments/assets/acc44b3a-f655-4575-97e6-7f89df83b34b)
