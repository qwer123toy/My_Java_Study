package kr.co.greenart.file;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service
@Primary
public class FileServiceImpl implements FileService {
	@Autowired
	private FileMapper mapper;
	@Override
	public void save(String name, byte[] fileSave) {
		
		Filelist f = Filelist.builder().name(name).fileSave(fileSave).build();
		
		mapper.save(f);
		
	}

	@Override
	public List<Filelist> showList() {
		
		return mapper.showList();
	}

	@Override
	public void read() {
		// TODO Auto-generated method stub
		
	}

}
