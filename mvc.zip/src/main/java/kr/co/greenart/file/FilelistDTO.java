package kr.co.greenart.file;

public class FilelistDTO {
    private int id;
    private String name;
    private String base64EncodedFilesave;

    // 생성자
    public FilelistDTO(int id, String name, String base64EncodedFilesave) {
        this.id = id;
        this.name = name;
        this.base64EncodedFilesave = base64EncodedFilesave;
    }

    // Getter 메서드
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getBase64EncodedFilesave() {
        return base64EncodedFilesave;
    }
}