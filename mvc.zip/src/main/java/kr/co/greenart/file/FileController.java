package kr.co.greenart.file;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;


//TODO 파일 저장, 파일 목록, 파일 읽기 기능을 DB에서 가능하도록
//1. 위의 추상 정의를 인터페이스로 정의한다. 
//2. 기존 구현 내용을 별도의 클래스(1번 인터페이스 구현)로 작성한다.
//3. 1번 인터페이스를 구현하는 DB 저장 클래스를 구현한다.
//4. 컨트롤러에서 필요한 객체 의존성을 DB 저장 객체 Bean으로 주입받는다.

@Controller
@RequestMapping("/file")
public class FileController {
	
	@Autowired
	private FileService service;
	
	@GetMapping
	public String fileForm() {
		return "fileForm";
	}

	@PostMapping // 이 메서드는 HTTP POST 요청을 처리하며, '/파일업로드 경로'로 매핑된 요청을 처리하게 됩니다.
	public String fileUpload(@RequestParam("upload") MultipartFile multipart) throws IOException {
		// 클라이언트로부터 업로드된 파일의 원래 파일 이름을 가져옵니다.
		// 이 이름은 사용자가 파일을 업로드할 때의 파일명입니다.
		String orignalFilename = multipart.getOriginalFilename();

		// 업로드된 파일의 내용을 바이트 배열로 읽어옵니다.
		// multipart.getBytes()는 파일의 내용을 메모리로 가져오며,
		// 이후 파일 시스템에 저장할 때 사용할 수 있습니다.
		byte[] bytes = multipart.getBytes();

		
		
		// 파일을 저장할 경로를 설정합니다. 여기서는 "d:\\upload\\" 폴더에 저장합니다.
		// Paths.get() 메서드를 사용하여 저장 디렉터리 경로를 나타내는 Path 객체를 생성합니다.
		Path p = Paths.get("d:\\upload\\");

		// Files.notExists(p)는 지정된 경로가 존재하지 않는지를 검사합니다.
		// 지정된 경로가 존재하지 않을 경우, 파일을 저장할 디렉터리를 생성합니다.
		if (Files.notExists(p)) {
			Files.createDirectories(p); // 주어진 경로에 필요한 디렉터리를 모두 생성합니다.
		}

		// 업로드된 파일을 저장할 파일 경로를 설정합니다.
		// p.resolve(originalFilename)은 저장할 경로(p)와 파일 이름을 결합하여 새로운 Path 객체를 반환합니다.
		// 이 Path 객체는 실제로 저장할 파일의 전체 경로를 나타냅니다.
		Path file = p.resolve(orignalFilename);

		// 파일을 해당 경로에 저장합니다.
		// Files.write()는 지정된 경로에 주어진 바이트 배열의 내용을 파일로 씁니다.
		// StandardOpenOption.CREATE_NEW 옵션은 파일이 이미 존재하지 않는 경우에 새로 생성하고,
		// StandardOpenOption.TRUNCATE_EXISTING 옵션은 이미 존재하는 파일일 경우, 내용을 지우고 새로 씁니다.
		Files.write(file, bytes, StandardOpenOption.CREATE_NEW, StandardOpenOption.TRUNCATE_EXISTING);

		// 파일 업로드 작업이 성공적으로 완료된 후, 루트 URL로 리다이렉트합니다.
		// 이를 통해 파일 업로드가 끝난 뒤 메인 페이지로 돌아가도록 합니다.
		return "redirect:/";
	}
	
	@GetMapping("/filelist")
	public String filelist(Model model) {
		List<Filelist> filelist = service.showList();
		
		 // Base64 인코딩을 적용하여 새로운 리스트 생성
	    List<FilelistDTO> filelistDTOs = filelist.stream().map(file -> {
	        // FilelistDTO는 Filelist의 name과 base64EncodedFilesave를 포함하는 새로운 DTO입니다.
	        String base64Encoded = Base64.getEncoder().encodeToString(file.getFileSave());
	        return new FilelistDTO(file.getId(), file.getName(), base64Encoded);
	    }).collect(Collectors.toList());

	    model.addAttribute("filelist", filelistDTOs);
		return "filelist";
	}

	
	@PostMapping("/filelist")
	public String filelistSaveDB(@RequestParam("upload") MultipartFile multipart) throws IOException {
		String orignalFilename = multipart.getOriginalFilename();

		// 업로드된 파일의 내용을 바이트 배열로 읽어옵니다.
		// multipart.getBytes()는 파일의 내용을 메모리로 가져오며,
		// 이후 파일 시스템에 저장할 때 사용할 수 있습니다.
		byte[] bytes = multipart.getBytes();
		
		service.save(orignalFilename,bytes);
		
		
		return "filelist";
	}
	
	@GetMapping("/links")
	public String links() {
		// "fileLinks"라는 뷰 이름을 반환합니다.
		// 이 뷰 이름을 통해 해당 JSP나 HTML 파일을 찾아 렌더링하게 됩니다.
		return "fileLinks";
	}

	@GetMapping("/download")
	// HTTP GET 요청이 "/download" URL로 들어올 때 이 메서드가 호출됩니다.
	// 이 요청은 다운로드할 파일의 이름을 매개변수로 전달받습니다.
	public ResponseEntity<?> download(@RequestParam String filename)
			throws MalformedURLException, UnsupportedEncodingException {
		// 파일이 저장된 경로를 나타내는 Path 객체를 생성합니다.
		// 여기서는 "d:\\upload\\" 디렉터리에 있는 파일을 가져오도록 설정합니다.
		Path p = Paths.get("d:\\upload\\", filename);

		// 해당 파일 경로를 기반으로 UrlResource 객체를 생성합니다.
		// 이 객체를 통해 파일을 읽고 스트림 형태로 제공할 수 있습니다.
		Resource resource =  new UrlResource(p.toUri());

		// HTTP 응답 헤더를 설정하기 위해 HttpHeaders 객체를 생성합니다.
		HttpHeaders headers = new HttpHeaders();
		
//		byte[] bytes = Files.readAllBytes(p);
//		Resource resource = new ByteArrayResource(bytes);

		// "Content-Type"을 "application/octet-stream"으로 설정하여 바이너리 데이터를 나타냅니다.
		// 이 설정은 다운로드할 때 파일의 MIME 유형을 지정하는 역할을 합니다.
		headers.set("Content-Type", "application/octet-stream");

		// "Content-Disposition" 헤더를 설정하여 파일이 첨부 파일로 다운로드되도록 지정합니다.
		// 여기서는 파일 이름을 URL 인코딩하여 파일이름의 특수 문자나 공백이 올바르게 처리되도록 합니다.
		headers.set("Content-Disposition", "attachment; filename=" + URLEncoder.encode(filename, "UTF-8"));

		// ResponseEntity 객체를 생성하여 HTTP 응답을 설정하고 반환합니다.
		// HTTP 상태 코드를 200 OK로 설정하고, 설정된 헤더와 파일 자원을 응답 본문에 포함시킵니다.
		return ResponseEntity.ok().headers(headers).body(resource);
	}

}
