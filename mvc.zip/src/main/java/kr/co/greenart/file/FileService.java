package kr.co.greenart.file;
//TODO 파일 저장, 파일 목록, 파일 읽기 기능을 DB에서 가능하도록
//1. 위의 추상 정의를 인터페이스로 정의한다. 
//2. 기존 구현 내용을 별도의 클래스(1번 인터페이스 구현)로 작성한다.
//3. 1번 인터페이스를 구현하는 DB 저장 클래스를 구현한다.
//4. 컨트롤러에서 필요한 객체 의존성을 DB 저장 객체 Bean으로 주입받는다.

import java.util.List;

public interface FileService {
	void save(String name, byte[] fileSave);
	
	List<Filelist> showList();
	
	void read();
}


