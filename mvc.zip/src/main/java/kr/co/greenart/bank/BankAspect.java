package kr.co.greenart.bank;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect // 이 클래스가 AOP(Aspect-Oriented Programming)의 관점(Aspect)을 정의하는 클래스임을 나타냅니다.
@Component // 이 클래스를 스프링의 빈으로 등록하여 관리할 수 있도록 합니다.
public class BankAspect {
	// 특정 메서드의 실행 전후에 로그를 남기는 기능을 제공합니다.

	@Before(value = "execution(public void kr.co.greenart.bank.TransferServiceImpl.transferMoney(..))")
	// @Before 어노테이션은 지정된 메서드가 실행되기 전에 수행할 작업을 정의합니다.
	// "execution(public void kr.co.greenart.bank.TransferServiceImpl.transferMoney(..))" 표현식은
	// TransferServiceImpl 클래스의 transferMoney 메서드가 실행되기 전에 printLog() 메서드가
	// 실행되도록 지정합니다.
	// "public void"는 접근 제어자와 반환 타입을 의미하며, ".."는 메서드의 매개변수에 관계없이
	// 모든 매개변수를 허용함을 나타냅니다.
	public void printLog() {
		// 이 메서드는 transferMoney 메서드가 호출되기 전에 로그를 출력하는 역할을 합니다.
		System.out.println("~~~로그 남기기~~~"); // 로그 메시지를 콘솔에 출력합니다.
	}

	@After(value = "execution(public void kr.co.greenart.bank.TransferServiceImpl.transferMoney(..))")
	// @After 어노테이션은 지정된 메서드가 실행된 후에 수행할 작업을 정의합니다.
	// 여기서는 transferMoney 메서드가 실행된 후에 printLogAfter() 메서드를 실행하도록 설정합니다.
	public void printLogAfter() {
		// 이 메서드는 transferMoney 메서드가 실행된 후에 로그를 출력하는 역할을 합니다.
		System.out.println("~~~작업 후에 호출됩니다~~~"); // 작업 완료 후 로그 메시지를 콘솔에 출력합니다.
	}

	@Pointcut("execution(* kr.co.greenart.bank.TransferServiceImpl.*(..))")
	// @Pointcut 어노테이션은 재사용 가능한 포인트컷 표현식을 정의합니다.
	// 여기서는 TransferServiceImpl 클래스의 모든 메서드를 대상으로 하는 포인트컷을 정의하고 있습니다.
	// "execution(* kr.co.greenart.bank.TransferServiceImpl.*(..))"는
	// TransferServiceImpl 클래스의 모든 메서드 호출을 대상으로 합니다.
	public void signature() {
		// 이 메서드는 실제로 실행되는 것이 아니며, 포인트컷을 식별하기 위한 이름을 제공합니다.
	}

	@Around(value = "signature()")
	// @Around 어노테이션은 지정된 포인트컷에 해당하는 메서드 호출 전, 후, 예외 발생 시점을 모두 제어할 수 있는 AOP 어드바이스를 정의합니다.
	// "signature()"는 앞서 정의한 포인트컷을 가리키며, TransferServiceImpl 클래스의 모든 메서드가 대상이 됩니다.
	public void testAround(ProceedingJoinPoint joinPoint) throws Throwable {
		// ProceedingJoinPoint는 호출되는 메서드에 대한 정보를 제공하며, 메서드 실행을 제어할 수 있는 객체입니다.
		// joinPoint.getArgs()는 현재 호출된 메서드의 인자(매개변수) 목록을 반환합니다.
		Object[] args = joinPoint.getArgs(); // 메서드의 인자들을 배열로 가져옵니다.

		try {
			// 메서드의 마지막 인자가 음수일 경우 예외를 던져 입출금 작업이 불가능하도록 합니다.
			if ((Integer) args[args.length - 1] <= 0) {
				throw new RuntimeException("음수 값만큼 입출금 할 수 없습니다"); // 유효하지 않은 인자에 대한 예외 발생
			}
			// before: 메서드 실행 전
			joinPoint.proceed(args);
			// joinPoint.proceed()는 원래의 메서드를 실행합니다.
			// 메서드 실행 후 after로 이어집니다.

			// after: 메서드 실행 후, 예외가 발생하지 않았을 때 실행될 코드입니다.
		} catch (Throwable ex) {
			// afterThrowing: 메서드 실행 중 예외가 발생했을 때 실행됩니다.
			System.out.println(ex.getMessage()); // 예외 메시지를 출력합니다.
			throw ex; // 예외를 다시 던져 호출한 쪽에서 예외를 처리할 수 있도록 합니다.
		}
	}


//	@Before("signature() && args(..,amount)")
//	// @Before 어노테이션은 signature() 포인트컷에 정의된 메서드가 호출되기 전에
//	// testParam 메서드를 실행하도록 설정합니다. "&& args(..,amount)"는 메서드의 매개변수 중
//	// 마지막 매개변수가 amount라는 이름으로 매칭될 때 실행되도록 조건을 추가합니다.
//	public void testParam(int amount) {
//		System.out.println("--파라미터 값을 확인하기--");
//		if (amount <= 0) {
//			throw new RuntimeException("음수 값만큼 입출금 할 수 없습니다");
//		}
//	}
	
//	public void testParam(int amount) {
//		// 이 메서드는 TransferServiceImpl 클래스의 메서드가 호출되기 전에
//		// 메서드의 특정 파라미터 값을 출력하는 역할을 합니다.
//		System.out.println("--파라미터 값을 확인하기--"); // 파라미터 값을 확인하기 시작
//		System.out.println(amount); // 전달된 파라미터 값(amount)을 출력합니다.
//		System.out.println("--파라미터 값을 확인하기--"); // 파라미터 값을 확인하기 종료
//	}
}
