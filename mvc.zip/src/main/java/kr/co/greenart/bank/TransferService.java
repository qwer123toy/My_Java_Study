package kr.co.greenart.bank;

public interface TransferService {   
    void transferMoney(int fromAccountId, int toAccountId, int amount);

    void withdraw(int accountId, int amount);

    void deposit(int accountId, int amount);
}
