package kr.co.greenart.bank;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TransferHistoryMapper {

	@Insert({"Insert INTO TransferHistory (fromAcc, toAcc, amount)",
			"VALUES (#{fromAccountId}, #{toAccountId}, #{amount})"
	})
	void insert(int fromAccountId, int toAccountId, int amount);

}
