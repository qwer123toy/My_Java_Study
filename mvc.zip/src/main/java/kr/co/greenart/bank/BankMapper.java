package kr.co.greenart.bank;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.context.annotation.Primary;

@Mapper
@Primary
public interface BankMapper extends BankRepository {
	@Select("SELECT balance FROM account WHERE id = #{accountId}")
	int getBalance(int accountId);
	
	@Update("UPDATE account SET balance = #{balance} WHERE id = #{accountId}")
	int update(int accountId, int balance);
}
