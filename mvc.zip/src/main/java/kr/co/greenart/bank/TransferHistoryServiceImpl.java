package kr.co.greenart.bank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service
@Primary
public class TransferHistoryServiceImpl implements TransferHistoryService {
	@Autowired
	private TransferHistoryMapper mapper;
	
	@Override
	public void insert(int fromAccountId, int toAccountId, int amount) {
		mapper.insert( fromAccountId, toAccountId, amount);
	}
}
