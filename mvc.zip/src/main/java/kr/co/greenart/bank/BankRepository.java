package kr.co.greenart.bank;

public interface BankRepository {
	int getBalance(int accountId);
	
	int update(int accountId, int balance);
}
