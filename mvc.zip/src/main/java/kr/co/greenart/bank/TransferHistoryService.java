package kr.co.greenart.bank;

public interface TransferHistoryService {
	void insert(int fromAccountId, int toAccountId, int amount);
}
