package kr.co.greenart.bank;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service // 이 클래스가 스프링 서비스로 관리되는 빈임을 나타냄
@Primary // 동일한 타입의 빈이 여러 개일 때 우선적으로 사용되도록 지정
public class TransferServiceImpl implements TransferService {
	@Autowired // BankRepository 타입의 빈을 자동으로 주입받음
	private BankRepository repo;
	@Autowired // TransferHistoryService 타입의 빈을 자동으로 주입받음
	private TransferHistoryService historyService;


	
	@Override
	@Transactional // 메서드 실행을 트랜잭션으로 감싸서 데이터 일관성을 보장
	public void transferMoney(int fromAccountId, int toAccountId, int amount) {
		// 송금 로직: 출금과 입금을 처리한 후, 이체 기록을 남김
		withdraw(fromAccountId, amount); // 출금 처리
		deposit(toAccountId, amount); // 입금 처리

		historyService.insert(fromAccountId, toAccountId, amount); // 이체 기록을 저장
	}

	@Override
	@Transactional // 출금을 트랜잭션 내에서 처리하여 데이터의 일관성을 유지
	public void withdraw(int accountId, int amount) {
		// 출금 금액이 0 이하인 경우 예외 발생
		if (amount <= 0) {
			throw new RuntimeException("마이너스 출금 nono해");
		}

		int balance = repo.getBalance(accountId); // 현재 계좌 잔액을 조회

		// 잔액이 출금 금액보다 적은 경우 예외 발생
		if (balance < amount) {
			throw new RuntimeException("잔고가 부족합니다");
		}

		balance -= amount; // 출금 금액을 잔액에서 차감

		repo.update(accountId, balance); // 업데이트된 잔액을 계좌에 반영
	}

	@Override
	@Transactional(readOnly = false) // 트랜잭션을 사용하여 입금을 처리 (읽기 전용이 아님을 명시)
	public void deposit(int accountId, int amount) {
		// 입금 금액이 0 이하인 경우 예외 발생
		if (amount <= 0) {
			throw new RuntimeException("마이너스 입금 nono해");
		}

		int balance = repo.getBalance(accountId); // 현재 계좌 잔액을 조회

		balance += amount; // 입금 금액을 잔액에 더함

		repo.update(accountId, balance); // 업데이트된 잔액을 계좌에 반영
	}
}
