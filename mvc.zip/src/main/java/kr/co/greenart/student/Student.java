package kr.co.greenart.student;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;
import org.springframework.lang.Nullable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@Builder
@NoArgsConstructor
public class Student {
	private Integer no;
	@NotNull
	@Size(min = 1, max = 5, message = "성은 5자")
	private String lastName;
	@NotNull
	@Size(min = 1, max = 20, message = "이름은 20자")
	private String firstName;
	@PositiveOrZero
	@Nullable
	@Min(value = 0, message = "최소 점수는 0원입니다")
	@Max(value = 100, message = "최대 점수은 100점입니다")
	private Integer korean;
	@Min(value = 0, message = "최소 점수는 0원입니다")
	@Max(value = 100, message = "최대 점수은 100점입니다")
	private Integer english;
	@Min(value = 0, message = "최소 점수는 0원입니다")
	@Max(value = 100, message = "최대 점수은 100점입니다")
	private Integer math;
}
