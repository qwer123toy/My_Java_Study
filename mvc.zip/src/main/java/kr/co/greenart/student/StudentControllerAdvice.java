package kr.co.greenart.student;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

// 컨트롤러의 보조적인 역할을 담당하는 어드바이스 클래스
// assignableTypes 속성으로 특정 컨트롤러(StudentController)를 대상으로 설정
@ControllerAdvice(assignableTypes = StudentController.class) 
public class StudentControllerAdvice {

    /**
     * 모든 요청에 대해 공통적으로 실행될 모델 데이터를 설정하는 메서드
     * "formModel"이라는 이름으로 Student 객체를 모델에 추가하여 뷰에서 사용할 수 있도록 함
     * @return 새로운 Student 객체
     */
    @ModelAttribute("formModel")
    public Student formModel() {
        return new Student();
    }

    /**
     * RuntimeException 예외가 발생할 때 호출되는 예외 처리 메서드
     * 예외 정보를 클라이언트에게 전달하며, 상태 코드 500과 함께 텍스트 형식으로 반환
     * @param e 발생한 RuntimeException
     * @return 예외 메시지를 담은 ResponseEntity 객체
     */
    @ExceptionHandler(value = RuntimeException.class)
    public ResponseEntity<String> errorHandling(RuntimeException e) {
        // 예외의 스택 트레이스를 콘솔에 출력
        e.printStackTrace();

        // 500 Internal Server Error 상태 코드와 함께 예외 메시지를 반환
        return ResponseEntity.status(500)
                .header("Content-Type", "text/plain; charset=utf-8")
                .body(e.getMessage());
    }
}
