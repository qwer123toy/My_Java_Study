package kr.co.greenart.student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service(value = "myService")//value로 구분 가능
@Primary // Bean을 넣어달라고 요청할 때 우선순위가 됨
public class StudentServiceImpl implements StudentService {
//Bean은 인터페이스 타입으로 Autowired를 하면 그 인터페이스를 구현하고 있는 객체를 연결해줌

	@Autowired
	private StudentMapper mapper;

	@Override
	@Transactional(readOnly = true)
	public List<Student> findAll() {

		return mapper.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Student findByPk(int no) {
		return mapper.findByPk(no);
	}

	@Override
	@Transactional(readOnly = true)
	public int count() {
		return mapper.count();
	}

	@Override
	@Transactional(readOnly = false) // 런타임 에러시 자동으로 RollBack
	public int save(Student s) {
		return mapper.save(s);
	}

	@Override
	public int update(Student student) {
		// TODO Auto-generated method stub
		return mapper.update(student);
	}

	@Override
	public List<Student> findPage(int limit, int offset) {
		// TODO Auto-generated method stub
		return mapper.findPage(limit, offset);
	}

}
