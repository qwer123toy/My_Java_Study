package kr.co.greenart.student;

import java.util.List;

public interface StudentService {
	List<Student> findAll();
	
	Student findByPk(int no);
	
	int count();

	List<Student> findPage(int limit, int offset);

	int save(Student s);
	
	int update(Student student);

}
