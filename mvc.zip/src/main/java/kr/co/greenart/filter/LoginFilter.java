package kr.co.greenart.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// 로그인 필터 클래스 구현, 사용자가 로그인되어 있는지 확인하여 로그인이 되어있지 않으면 
//로그인 페이지로 리다이렉트하는 기능을 수행함
public class LoginFilter implements Filter {

	@Override
	// doFilter 메서드는 필터의 핵심 메서드로, 요청과 응답을 처리하는 로직을 포함함
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// HttpServletRequest로 변환하여 세션을 가져옴
		HttpSession session = ((HttpServletRequest) request).getSession();

		// 세션에서 "username"이라는 이름의 속성을 가져와 로그인 상태를 확인
		String username = (String) session.getAttribute("username");

		// 만약 세션에 username 속성이 없으면, 즉 로그인이 되어있지 않으면
		if (username == null) {
			// 로그인 페이지로 리다이렉트 시킴
			((HttpServletResponse) response).sendRedirect("/login");
		}

		// 로그인이 되어있으면 다음 필터나 서블릿으로 요청을 넘김
		chain.doFilter(request, response);
	}
}
