package kr.co.greenart.calc;

// 1. 구현체 구현하기
// 2. 4개의 메소드에 각 입력 파라미터에 null을 전달받았을 때, 기본값 0으로 처리한다.
// 3. 모든 메소드의 입력값 및 반환 값을 콘솔 로그에 남긴다.
// 4. divide 메소드에 right 파라미터에 0이 전달되었을 때, IlligalArgumentException을 발생시킨다.
// 5. 메소드 처리 과정 중, 예외가 발생하면 예외메시지를 콘솔 로그에 남긴다.
public interface Calculator {
	Integer plus(Integer left, Integer right);
	Integer minus(Integer left, Integer right);
	Integer multiply(Integer left, Integer right);
	Integer divide(Integer left, Integer right);
}
