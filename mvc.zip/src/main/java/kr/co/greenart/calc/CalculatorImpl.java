package kr.co.greenart.calc;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service // 이 클래스가 스프링 서비스로 관리되는 빈임을 나타냄
@Primary // 동일한 타입의 빈이 여러 개일 때 우선적으로 사용되도록 지정
public class CalculatorImpl implements Calculator {
	

	@Override
	public Integer plus(Integer left, Integer right) {
		Integer result = left + right;
		return result;
	}
	
	@Override
	public Integer minus(Integer left, Integer right) {
		Integer result = left - right;
		return result;
	}
	
	@Override
	public Integer multiply(Integer left, Integer right) {
		Integer result = left * right;
		return result;	}
	
	@Override
	public Integer divide(Integer left, Integer right) {
		Integer result = left / right;
		return result;
	}


	
}
