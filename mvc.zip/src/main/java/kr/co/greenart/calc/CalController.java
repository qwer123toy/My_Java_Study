package kr.co.greenart.calc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/calc")
public class CalController {
	private static final Logger log = LoggerFactory.getLogger(CalController.class);
	
	@GetMapping
	public String numForm() {
		return "numForm";
	}
	
	@PostMapping
	public String numResult(@RequestParam("left") int left
			, @RequestParam int right
			, Model model) {
		log.info("left: " + left);
		log.info("right: " + right);
		
		model.addAttribute("left", left);
		model.addAttribute("right", right);
		
		return "numResult";
	}
}






