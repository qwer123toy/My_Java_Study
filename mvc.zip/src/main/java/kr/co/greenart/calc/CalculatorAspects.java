package kr.co.greenart.calc;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect // 이 클래스는 AOP(Aspect-Oriented Programming)에서 사용되는 관점을 정의하는 Aspect 클래스입니다.
@Component // 이 클래스를 Spring의 빈으로 등록하여 관리할 수 있도록 합니다.
public class CalculatorAspects {

	@Around("execution(* kr.co.greenart.calc.CalculatorImpl.*(..))")
	// 이 어드바이스는 CalculatorImpl 클래스의 모든 메서드 호출에 대해 적용됩니다.
	// 메서드 호출 전, 후 및 예외 발생 시점에 대한 처리를 제어합니다.
	public Object testAround(ProceedingJoinPoint joinPoint) throws Throwable {
		try {
			// 호출된 메서드의 인자를 가져옵니다.
			Object[] args = joinPoint.getArgs();
			// 각 인자를 순회하면서 null 체크 및 초기화 작업을 수행합니다.
			for (int i = 0; i < args.length; i++) {
				if (args[i] == null) {
					args[i] = 0; // null인 경우 0으로 초기화합니다.
				}
				// 현재 인자의 인덱스와 값을 출력합니다.
				System.out.println(i + "번째 파라미터 값 : " + args[i]);
			}

			// 원래 메서드를 인자를 전달하여 실행합니다.
			Object proceed = joinPoint.proceed(args);
			// 메서드의 반환 값을 출력합니다.
			System.out.println("메소드 반환 값 : " + proceed);
			// 메서드의 반환 값을 호출한 곳으로 반환합니다.
			return proceed;

		} catch (Throwable ex) {
			// 예외가 발생한 경우 예외 메시지를 출력합니다.
			System.out.println(ex.getMessage());
			// 예외를 다시 던져서 호출한 쪽에서 처리할 수 있도록 합니다.
			throw ex;
		}
	}

	
	@Before("execution(* kr.co.greenart.calc.CalculatorImpl.divide(..)) && args(..,right)")
	// @Before 어노테이션은 지정된 포인트컷(이 경우 divide 메서드 호출 전)에 대해 실행될 로직을 정의합니다.
	// 여기서는 CalculatorImpl 클래스의 divide 메서드에서 마지막 인자(right)가 0인지 확인합니다.
	public void testBeforeDivide(Integer right) {
	    // 메서드의 인자로 전달된 right 값이 0인지 체크합니다.
	    if (right == 0) {
	        // right가 0인 경우 IllegalArgumentException 예외를 던져 나눗셈을 수행할 수 없음을 알립니다.
	        throw new IllegalArgumentException("0으로 나눌 수 없습니다"); 
	    }
	}

}
