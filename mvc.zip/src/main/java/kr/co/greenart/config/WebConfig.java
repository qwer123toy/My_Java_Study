package kr.co.greenart.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import kr.co.greenart.interceptor.LoginInterceptor;

@Configuration
// Spring MVC 설정을 활성화합니다.
@EnableWebMvc
// "kr.co.greenart" 패키지를 컴포넌트 스캔하여 Spring Bean으로 등록합니다.
@ComponentScan("kr.co.greenart")
public class WebConfig implements WebMvcConfigurer {

	@Autowired
	private LoginInterceptor loginInterceptor; // LoginInterceptor를 주입받아 사용합니다.

	@Bean // 이 메서드가 스프링의 빈으로 등록됨을 나타냅니다.
	public MultipartResolver multipartResolver() {
	    // CommonsMultipartResolver는 스프링에서 파일 업로드를 처리하기 위한 기본 구현입니다.
	    CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
	    
	    // 파일 업로드 시 사용할 인코딩을 UTF-8로 설정합니다.
	    multipartResolver.setDefaultEncoding("UTF-8");
	    
	    // 설정된 MultipartResolver 객체를 반환합니다.
	    return multipartResolver;
	}

	
	// 뷰 리졸버(View Resolver)를 설정하는 메서드입니다.
	@Override
	public void configureViewResolvers(ViewResolverRegistry registry) {
		// JSP 파일의 경로와 확장자를 설정합니다.
		// "/WEB-INF/views/" 경로에 있는 JSP 파일을 사용하며, 확장자는 ".jsp"입니다.
		registry.jsp("/WEB-INF/views/", ".jsp");
	}

	// 정적 리소스 핸들러를 추가하는 메서드입니다.
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		// "/static/**" 경로로 요청이 들어오면, "/static/" 폴더에 있는 리소스들을 참조합니다.
		// 즉, 정적 리소스(이미지, CSS, JavaScript 등)의 위치를 지정합니다.
		registry.addResourceHandler("/static/**").addResourceLocations("/static/");
	}

	@Override
	// CORS(Cross-Origin Resource Sharing) 설정을 추가하는 메서드
	public void addCorsMappings(CorsRegistry registry) {
		// "/api/**" 경로에 대해 CORS 요청을 허용하도록 설정
		// allowedOrigins("*")는 모든 도메인에서의 요청을 허용함
		// allowedHeaders("*")는 모든 헤더를 허용
		// allowedMethods("GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS")는 특정 HTTP
		// 메서드들에 대해서만 허용
		registry.addMapping("/api/**").allowedOrigins("*") // 모든 도메인에서의 요청을 허용
				.allowedHeaders("*") // 모든 요청 헤더를 허용
				.allowedMethods("GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS");
		// 허용할 HTTP 메서드를 지정
	}

	// 인터셉터를 추가하는 메서드입니다.
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		// LoginInterceptor를 등록하고, "/book/**" 및 "/student/**" 경로에 대해 적용합니다.
		// 해당 경로로 요청이 들어올 때마다 로그인 인터셉터가 동작합니다.
		registry.addInterceptor(loginInterceptor).addPathPatterns("/book/**").addPathPatterns("/student/**");
	}
}
