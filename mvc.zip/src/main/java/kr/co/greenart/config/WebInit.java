package kr.co.greenart.config;

import java.util.EnumSet;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterRegistration.Dynamic;
import javax.servlet.ServletContext;

import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import kr.co.greenart.filter.LoginFilter;

/**
 * 이 클래스는 Spring Web MVC에서 DispatcherServlet을 초기화하는 설정 클래스입니다.
 * AbstractAnnotationConfigDispatcherServletInitializer를 상속받아 필요한 설정들을 구현합니다.
 * XML 설정을 사용하지 않고, 자바 클래스를 통해 Spring의 설정을 구성합니다.
 */
public class WebInit extends AbstractAnnotationConfigDispatcherServletInitializer {

    /**
     * 애플리케이션의 전역 설정을 담당하는 RootConfig 클래스를 반환합니다.
     * 루트 애플리케이션 컨텍스트는 주로 서비스, 리포지토리 등의 전역적인 bean을 관리합니다.
     * @return RootConfig 클래스를 담은 배열
     */
    @Override
    protected Class<?>[] getRootConfigClasses() {
        // RootConfig 클래스를 반환하여 루트 애플리케이션의 설정을 제공합니다.
        return new Class[] { RootConfig.class };
    }

    /**
     * DispatcherServlet에 대한 설정을 담당하는 WebConfig 클래스를 반환합니다.
     * 서블릿 애플리케이션 컨텍스트는 주로 웹 관련 bean을 관리합니다.
     * @return WebConfig 클래스를 담은 배열
     */
    @Override
    protected Class<?>[] getServletConfigClasses() {
        // WebConfig 클래스를 반환하여 서블릿 애플리케이션의 설정을 제공합니다.
        return new Class[] { WebConfig.class };
    }

    /**
     * DispatcherServlet이 처리할 URL 패턴을 정의합니다.
     * 여기서는 "/" 경로를 매핑하여 모든 요청을 DispatcherServlet으로 처리하도록 설정합니다.
     * @return "/" 패턴을 포함한 문자열 배열
     */
    @Override
    protected String[] getServletMappings() {
        // "/" 경로로 들어오는 모든 요청을 DispatcherServlet에서 처리하도록 매핑합니다.
        return new String[] { "/" };
    }

    /**
     * 서블릿 필터를 설정하는 메서드입니다.
     * 여기서는 UTF-8 인코딩을 적용하기 위해 CharacterEncodingFilter를 설정합니다.
     * @return 설정된 필터 배열
     */
    @Override
    protected Filter[] getServletFilters() {
        // UTF-8로 인코딩 설정을 적용하기 위한 필터를 반환합니다.
        CharacterEncodingFilter encodingFilter = new CharacterEncodingFilter("UTF-8", true);
        
        // 필터 배열에 encodingFilter를 포함하여 반환
        return new Filter[] { encodingFilter };
    }

//	/**
//     * 필터를 수동으로 등록하는 메서드입니다.
//     * 여기서는 LoginFilter를 "/book" URL 패턴에 적용하도록 설정합니다.
//     * (현재 주석 처리된 코드로 활성화하려면 주석을 해제해야 합니다.)
//     * @param servletContext 서블릿 컨텍스트
//     * @param filter 적용할 필터
//     * @return 등록된 필터 객체
//     */
//	@Override
//	protected Dynamic registerServletFilter(ServletContext servletContext, Filter filter) {
//		// LoginFilter를 등록하고 필터 이름을 "LoginFilter"로 설정합니다.
//		Dynamic dynamic = servletContext.addFilter("LoginFilter", new LoginFilter());
//		
//		// DispatcherType.REQUEST, FORWARD, ERROR에 대해 필터가 작동하도록 설정하고
//		// "/book" 경로에 필터를 매핑합니다.
//		EnumSet<DispatcherType> dispatcherTypes = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.ERROR);
//		
//		// 필터가 "/book" 경로에서만 작동하도록 설정
//		dynamic.addMappingForUrlPatterns(dispatcherTypes, true, "/book");
//		
//		// 필터 객체를 반환
//		return dynamic;
//	}
}
