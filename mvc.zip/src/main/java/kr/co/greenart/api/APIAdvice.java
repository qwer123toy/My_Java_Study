package kr.co.greenart.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import kr.co.greenart.api.Page;
import kr.co.greenart.book.Book;
import kr.co.greenart.book.BookMapper;
//모든 @RestController에 대한 예외를 처리하는 클래스
@ControllerAdvice(annotations = RestController.class)
public class APIAdvice {
	
	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<?> notFound() {
	    // NotFoundException 예외가 발생했을 때 호출되는 메서드입니다.
	    // 이 예외는 요청한 리소스가 존재하지 않을 때 발생합니다.
	    
	    // 404 Not Found 응답을 생성하여 반환합니다.
	    return ResponseEntity.notFound().build(); // 응답 본문 없이 404 상태 코드만 반환
	}

	
	   @ExceptionHandler(MethodArgumentNotValidException.class)
	    public ResponseEntity<?> notValid(MethodArgumentNotValidException e) {
	        // MethodArgumentNotValidException 예외가 발생했을 때 호출되는 메서드입니다.
	        // 이 예외는 클라이언트에서 전송한 데이터가 유효성 검사를 통과하지 못할 때 발생합니다.
	        
	        // 예외에서 필드 오류 정보를 가져옵니다.
	        List<FieldError> fieldErrors = e.getFieldErrors();
	        // 오류 메시지를 저장할 리스트를 생성합니다.
	        List<String> messages = new ArrayList<>();
	        
	        // 각 필드 오류에 대해 기본 오류 메시지를 리스트에 추가합니다.
	        for (FieldError error : fieldErrors) {
	            messages.add(error.getDefaultMessage()); // 필드 오류의 기본 메시지를 추가
	        }
	        
	        // 400 Bad Request 응답을 생성하여 반환합니다.
	        // 응답 헤더에 Content-Type을 "application/json; charset=utf-8"로 설정합니다.
	        return ResponseEntity.badRequest()
	                .header("Content-Type", "application/json; charset=utf-8")
	                .body(messages); // 응답 본문에 필드 오류 메시지 리스트를 포함합니다.
	    }


	    @ExceptionHandler(HttpMessageNotReadableException.class)
	    public ResponseEntity<?> notJson() {
	        // HttpMessageNotReadableException 예외가 발생했을 때 호출됩니다.
	        // 유효하지 않은 JSON 형식의 요청 본문이 클라이언트로부터 전달된 경우를 처리합니다.
	        	
	        // 예외 메시지를 저장할 Map 객체를 생성합니다.
	        Map<String, Object> message = new HashMap<>();
	        // 예외 메시지로 "유효한 JSON 형식이 아닙니다."를 추가합니다.
	        message.put("message", "유효한 JSON 형식이 아닙니다.");
	        
	        // HTTP 응답을 생성하여 반환합니다.
	        // 응답 상태 코드를 400 Bad Request로 설정하고, 
	        // 응답 헤더에 Content-Type을 "application/json; charset=utf-8"로 지정하여
	        // 응답 본문을 JSON 형식으로 설정합니다.
	        return ResponseEntity.badRequest()
	                .header("Content-Type", "application/json; charset=utf-8")
	                .body(message); // 응답 본문에 예외 메시지를 포함한 Map 객체를 설정합니다.
	    }
   
}
