package kr.co.greenart.api.book;

import java.util.List;

import kr.co.greenart.api.Page;
import kr.co.greenart.book.Book;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BookDTO {
	private List<Book> datas;
	private Page page;
}
