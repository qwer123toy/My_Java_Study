package kr.co.greenart.api.student;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import kr.co.greenart.api.NotFoundException;
import kr.co.greenart.api.Page;
import kr.co.greenart.student.Student;
import kr.co.greenart.student.StudentService;

@RestController // 사용할 수도 있습니다. @Controller와 @ResponseBody를 합친 역할을 합니다.
@RequestMapping("/api/student")
public class StudentAPIController {

	@Autowired
	private StudentService service;

	@GetMapping
	public List<Student> findAll() {
		return service.findAll();
	}

	@GetMapping(params = "page")
	public studentDTO findPage(@RequestParam(name = "page", defaultValue = "0") int page,
			@RequestParam(name = "size", defaultValue = "10") int size) {
		// 페이지당 최대 책의 개수를 설정합니다.
		int limit = size;
		// 요청한 페이지의 시작 인덱스를 계산합니다.
		int offset = page * size;
		// 데이터베이스에서 총 책의 개수를 조회합니다.
		int totalItems = service.count();
		// 총 페이지 수를 계산합니다.
		int totalPages = (int) Math.ceil((double) totalItems / size) - 1;

		// BookMapper를 통해 요청한 페이지의 책 목록을 조회하고, 페이지 정보를 포함하는 BookDTO 객체를 반환합니다.
		return new studentDTO(service.findPage(limit, offset), new Page(page, size, totalItems, totalPages));
	}

	/**
	 * 책의 ID를 이용하여 특정 책의 정보를 조회하는 메서드
	 * 
	 * @param bookId 요청한 책의 ID
	 * @return 요청한 ID에 해당하는 책 정보를 JSON 형식으로 반환
	 */
	@GetMapping("/{no}")
	public Student findByPk(@PathVariable int no) {

		Student s = service.findByPk(no);
		if(s==null) {
			throw new NotFoundException();
		}
		return s;
	}

	/**
	 * 새로운 책 정보를 삽입하는 메서드 (단순히 성공 메시지만 반환)
	 * 
	 * @return 삽입 성공 여부를 나타내는 메시지를 JSON 형식으로 반환
	 */
	@PostMapping
	public Map<String, Object> save(@RequestBody @Valid Student student) {
		// 클라이언트에서 전달된 JSON 데이터를 Book 객체로 변환합니다. (@RequestBody 어노테이션을 통해 자동 변환)

		// 데이터베이스에 새로운 책 정보를 삽입합니다.
		service.save(student);

		// 결과를 저장할 Map 객체를 생성합니다.
		Map<String, Object> result = new HashMap<>();

		// 삽입 성공 메시지를 추가합니다.
		result.put("message", "success");
		// 삽입된 책 객체를 결과에 추가합니다.
		result.put("created", student);

		// 삽입된 책의 링크를 생성합니다.
		// 예를 들어, "/api/book/{bookId}" 형식으로 삽입된 책의 ID를 포함한 경로를 만듭니다.
		UriComponents uri = UriComponentsBuilder.fromPath("/api/student").pathSegment(String.valueOf(student.getNo())) // Book
																														// 객체에서
																														// 생성된
																														// ID를
																														// 경로의
																														// 일부로
																														// 추가
				.build();
		// 생성된 URI 링크를 결과에 추가합니다.
		result.put("link", uri.toString());

		// 결과를 반환합니다.
		// 반환된 Map은 삽입 성공 메시지, 생성된 책 정보, 그리고 새로 생성된 책의 URI 링크를 포함합니다.
		return result;
	}

}
