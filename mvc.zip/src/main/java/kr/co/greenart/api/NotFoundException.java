package kr.co.greenart.api;

public class NotFoundException extends RuntimeException{

}
