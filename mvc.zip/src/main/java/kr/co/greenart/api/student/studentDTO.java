package kr.co.greenart.api.student;

import java.util.List;

import kr.co.greenart.api.Page;
import kr.co.greenart.student.Student;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class studentDTO {
	private List<Student> datas;
	private Page page;
}
