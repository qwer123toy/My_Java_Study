package kr.co.greenart.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@ControllerAdvice(basePackages = "kr.co.greenart")
public class UserControllerAdvice {
	@ExceptionHandler(value = {
		BadCredentialException.class
		, DisabledUserException.class
		, NoUserNameException.class
		
	})
	public String userError() {
		return "login";
	}
}
