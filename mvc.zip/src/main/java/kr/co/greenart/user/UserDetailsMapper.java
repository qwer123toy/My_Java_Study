package kr.co.greenart.user;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface UserDetailsMapper {
	@Insert({"INSERT INTO users (username, password, enabled)"
		, "VALUES (#{username}, #{password}, #{enabled})"
	})
	int createUser(UserDetails user);
	
	@Select("SELECT * FROM users WHERE username = #{username}")
	@Results(id = "userResults"
		, value = {
				@Result(column = "username", property = "username", id = true)
				, @Result(column = "password", property = "password")
				, @Result(column = "enabled", property = "enabled")
		}
	)
	UserDetails loadUserByUsername(String username);
	
	
	@Update("UPDATE users SET password=#{password} where username=#{username}")
	@ResultMap("userResults")
	int updatePassword(UserDetails user);
}



