package kr.co.greenart.user;

public interface UserDetailManager {
	UserDetails loadUserByUsername(String username);
	
	int createUser(UserDetails user);
	
	int updatePassword(UserDetails user);

}
