package kr.co.greenart.user;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString 
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class UserDetails {
	private String username;
	private String password;
	private Boolean enabled;
}
