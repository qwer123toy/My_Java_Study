package kr.co.greenart.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

// 어어~ 이게 뭐여, UserDetailManagerImpl 클래스가 이리 생겨부렀네.
// 나 이덕화, 봐줄테니까 걱정 말라구~

@Service
@Primary
public class UserDetailManagerImpl implements UserDetailManager {
    // 어어~ 이거이 자바 스프링의 유명한 의존성 주입이구만. mapper 넣어줬네!
    @Autowired
    private UserDetailsMapper mapper;
    
    @Override
    @Transactional(readOnly = true)  // 어어~ 데이터 읽기만 한다는 거여~ 변경은 없는 거래~
    public UserDetails loadUserByUsername(String username) {
        // 어어~ 이게 사용자의 이름을 받아서 그에 맞는 정보를 찾아온다는 거지~ 오케이~
    	UserDetails find = mapper.loadUserByUsername(username);
    	
    	if(find == null) {
    		throw new NoUserNameException();
    	}
    	if(!find.getEnabled()) {
    		throw new DisabledUserException();
    	}
    	
        return mapper.loadUserByUsername(username);
    }

    @Override
    @Transactional(readOnly = false)  // 어어~ 이제 이거이 데이터를 바꾼다는 거여~ 꼼꼼히 챙기라고~
    public int createUser(UserDetails user) {
        // 어어~ 유저가 활성화됐다는 걸 true로 설정해줬구만~
        user.setEnabled(true);
        // 어어~ 이제 mapper가 유저를 만들기 위해 호출됐네. 잘들어가라~
        return mapper.createUser(user);
    }

	@Override
	public int updatePassword(UserDetails user) {
		// TODO Auto-generated method stub
		return mapper.updatePassword(user);
	}
}
