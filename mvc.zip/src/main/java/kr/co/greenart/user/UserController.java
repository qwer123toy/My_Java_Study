package kr.co.greenart.user;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

	@Autowired
	private UserDetailManager service;

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@PostMapping("/login")
	public String loginSubmit(UserDetails user, HttpSession session) {
		UserDetails find = service.loadUserByUsername(user.getUsername());
		
		if (!find.getPassword().equals(user.getPassword())) {
			throw new BadCredentialException();
		}
		session.setAttribute("username", find.getUsername());
		return "redirect:/";
	}

	@GetMapping("/signup")
	public String signup() {
		return "signup";
	}

	@PostMapping("/signup")
	public String signupSubmit(UserDetails user) {
		int result = service.createUser(user);

		return "redirect:/";
	}
	
	// 로그아웃 기능 추가
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate(); // 세션 무효화 (로그아웃 처리)
		return "redirect:/"; // 홈 페이지로 리다이렉트
	}

	// 비번 변경
	@GetMapping("/update")
	public String Userupdate(HttpSession session, Model model) {
		String username = (String) session.getAttribute("username");
		UserDetails user = service.loadUserByUsername(username);
		model.addAttribute("user", user);
		return "userUpdate"; // 홈 페이지로 리다이렉트
	}
	
	// 비번 변경
	@PostMapping("/update")
	public String UserupdatePost(UserDetails user) {
		service.updatePassword(user);
		return "redirect:/"; // 홈 페이지로 리다이렉트
	}
	
}
