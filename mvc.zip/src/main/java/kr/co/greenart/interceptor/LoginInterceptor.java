package kr.co.greenart.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

// LoginInterceptor 클래스는 Spring MVC에서 인터셉터로 동작하며, 사용자가 로그인했는지 여부를 확인하는 역할을 함
@Component
public class LoginInterceptor implements HandlerInterceptor {

	@Override
	// preHandle 메서드는 컨트롤러가 요청을 처리하기 전에 실행되며, 로그인 여부를 확인하는 로직을 포함함
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, 
			Object handler)
			throws Exception {

		// HttpServletRequest에서 세션을 가져옴
		HttpSession session = request.getSession();

		// 세션에서 "username"이라는 속성을 가져와 로그인 상태를 확인
		String username = (String) session.getAttribute("username");

		// 만약 세션에 username 속성이 없으면, 즉 로그인이 되어있지 않으면
		if (username == null) {
			// 로그인 페이지로 리다이렉트하고 요청을 중단시킴 (false 반환)
			response.sendRedirect("/login");
			return false;
		}

		// 로그인이 되어있으면 true를 반환하여 요청을 계속 진행함
		return true;
	}
}
