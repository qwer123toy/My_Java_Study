package kr.co.greenart;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.Test;
import org.junit.function.ThrowingRunnable;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import kr.co.greenart.bank.BankMapper;
import kr.co.greenart.bank.TransferService;
import kr.co.greenart.calc.Calculator;
import kr.co.greenart.config.RootConfig;
import kr.co.greenart.config.WebConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { RootConfig.class, WebConfig.class })
@WebAppConfiguration
public class TestCal {
	@Autowired
	private Calculator cal;
	
	@Test
	public void testPlus() {
		Integer result = cal.plus(10, 10);
		assertEquals((long) 20, (long) result);
	}
	
	@Test
	public void testPlusNull() {
		Integer result = cal.plus(null, null);
		assertEquals((long) 0, (long) result);
	}
	
	@Test
	public void testDivide() {
		assertThrows(IllegalArgumentException.class, new ThrowingRunnable() {
			@Override
			public void run() throws Throwable {
				cal.divide(null, null);
			}
		});
	}
}





