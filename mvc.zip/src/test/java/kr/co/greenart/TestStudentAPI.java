package kr.co.greenart;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.json.JsonMapper;

import kr.co.greenart.config.RootConfig;
import kr.co.greenart.config.WebConfig;
import kr.co.greenart.student.Student;

// JUnit4 테스트를 위한 클래스 설정
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { RootConfig.class, WebConfig.class }) // 스프링 설정 파일을 지정
@WebAppConfiguration // 웹 애플리케이션 컨텍스트를 위한 설정
public class TestStudentAPI {
    @Autowired
    private WebApplicationContext webContext; // 웹 애플리케이션 컨텍스트 주입
    
    private MockMvc mock; // MockMvc 객체 선언
    
    @Before
    public void initMock() {
        // MockMvc를 웹 애플리케이션 컨텍스트로 초기화
        mock = MockMvcBuilders.webAppContextSetup(webContext).build();
    }
    
    /**
     * 학생 API의 전체 목록을 가져오는 GET 요청 테스트
     * @throws Exception 예외 처리
     */
    @Test
    public void testGet() throws Exception {
        // GET 요청을 수행하고 기대하는 결과를 검증
        mock.perform(get("/api/student"))
            .andExpect(status().isOk()) // HTTP 상태 코드가 200 OK인지 확인
            .andExpect(content().contentType("application/json")) // 응답 Content-Type이 JSON인지 확인
            .andDo(print()) // 요청 및 응답 내용을 출력
            .andExpect(jsonPath("$[0]no").exists()); // 첫 번째 학생의 'no' 필드가 존재하는지 확인
    }
    
    /**
     * 특정 학생의 ID를 기준으로 정보를 가져오는 GET 요청 테스트
     * @throws Exception 예외 처리
     */
    @Test
    public void testGetPk() throws Exception {
        // 특정 학생 ID(1)에 대한 GET 요청을 수행하고 기대하는 결과를 검증
        mock.perform(get("/api/student/3"))
            .andExpect(status().isOk()) // HTTP 상태 코드가 200 OK인지 확인
            .andExpect(content().contentType("application/json")) // 응답 Content-Type이 JSON인지 확인
            .andDo(print()) // 요청 및 응답 내용을 출력
            .andExpect(jsonPath("$.no").value("3")) // 응답 JSON에서 'no' 필드의 값이 "3"인지 확인
            .andExpect(jsonPath("$.lastName").value("김")) ; // 응답 JSON에서 'lastName' 필드의 값이 "김"인지 확인
            
    }
    
    @Test
    public void testGetPkNotFound() throws Exception{
        mock.perform(get("/api/student/1"))
        .andExpect(status().isNotFound());

    }
    
    @Test
    public void testPost() throws Exception{
    	mock.perform(post("/api/student").content("잘못된 json"))
    	.andExpect(status().is4xxClientError());
    }
    
    @Test
    public void testPostUnvaild() throws Exception{
    	Student s = new Student();
    	s.setKorean(-70);
    	
    	JsonMapper mapper = new JsonMapper();
    	String json = mapper.writeValueAsString(s);
    	
    	mock.perform(post("/api/student").content("잘못된 json"))
    	.andExpect(status().is4xxClientError());
    	
    }
    
    
}
