package kr.co.greenart;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.Test;
import org.junit.function.ThrowingRunnable;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import kr.co.greenart.bank.BankMapper;
import kr.co.greenart.bank.TransferService;
import kr.co.greenart.config.RootConfig;
import kr.co.greenart.config.WebConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { RootConfig.class, WebConfig.class })
@WebAppConfiguration
public class TestTransferSerivce {
	@Autowired
	private TransferService service;
	@Autowired
	private BankMapper repo;
	
	@Test
	@Transactional
	@Rollback
	public void testDeposit() {
		assertThrows(RuntimeException.class, new ThrowingRunnable() {
			@Override
			public void run() {
				int id = 1;
				
				int amount = 5000;
				
				service.deposit(id, amount);
			}
		});
	}
	
	@Test
	public void testTransfer() {
		int from = 1;
		int to = 2;
		
		int fromBal = repo.getBalance(from);
		int toBal = repo.getBalance(to);
		
		service.transferMoney(from, to, 5000);
		
		assertEquals(fromBal - 5000, repo.getBalance(from));
		assertEquals(toBal + 5000, repo.getBalance(to));
	}
}