package kr.co.greenart;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import javax.transaction.Transactional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import kr.co.greenart.config.RootConfig;
import kr.co.greenart.config.WebConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { RootConfig.class, WebConfig.class })
@WebAppConfiguration
public class TestUserMock {
	@Autowired
	private WebApplicationContext webContext;
	
	private MockMvc mock;
	//웹 요청을 흉내낼 수 있는 요소
	
	//초기화를 해줘야됨
	@Before
	public void initMock() {
		mock = MockMvcBuilders.webAppContextSetup(webContext).build();
	}
	
	@Test
	public void testSignup() throws Exception {
		mock.perform(get("/signup"))
			.andExpect(status().isOk())
			.andExpect(view().name("signup"));//foward된 뷰의 이름이 signup인지 확인
	}
	
	@Test
	@Transactional
	@Rollback
	public void testSignupSubmit() throws Exception{
		mock.perform(post("/signup").param("userName", "newuser").param("password", "newpass"))
				.andExpect(status().is3xxRedirection())
				.andExpect(redirectedUrl("/"));
	}
	
	@Test
	public void testPlain() throws Exception {
		mock.perform(get("/plain"))
			.andExpect(status().isOk())
			.andExpect(content().contentType("text/plain; charset=utf-8"))
			.andExpect(content().string("뷰이름이 아니라 일반 텍스트를 응답 바디에 전송하고 싶습니다."));
	}
}














